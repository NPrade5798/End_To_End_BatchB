package com.javasampleapproach.springrest.mysql.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.User;
import com.javasampleapproach.springrest.mysql.repo.UserRepository;

@CrossOrigin(origins="https://localhost:4200")

	@RestController
	@RequestMapping("/api")
	public class UserController {
		@Autowired
		UserRepository repository;

		
		@GetMapping("/user/{id}")
		public Optional <User> getUser(@PathVariable("id") long id)
		{
			Optional<User> user =repository.findById(id);
			return user;
		}
}