package com.javasampleapproach.springrest.mysql.repo;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import org.springframework.stereotype.Repository;

import com.javasampleapproach.springrest.mysql.model.Technologies;

@Repository

public interface TechnologiesRepository extends JpaRepository <Technologies, Long> {
//	@Query(value="SELECT * FROM technologies ", nativeQuery=true)
// List<Technologies> getSkill(@Param("id") long id);
	
@Query(value="SELECT * FROM technologies t where t.skillname=?1 and t.start_time=?2",nativeQuery=true)
	public List<Technologies> getSkillName(String name,String start_time);
}
