package com.javasampleapproach.springrest.mysql.model;

public class SigninModel {
	private long skill_id;
	private long mid;
	private String end_time;
	private String start_time;
	private String skillname;
	private String mentor_name;
	private int self_rating;
	private float years_of_experience;
	private String facilities_offered;
	private float amount;
	
	
	public SigninModel()
	{
	
	}
	
	public SigninModel(long skill_id, long mid, String end_time, String start_time, String skillname,
			String mentor_name, int self_rating, float years_of_experience, String facilities_offered, float amount) {
		super();
		this.skill_id = skill_id;
		this.mid = mid;
		this.end_time = end_time;
		this.start_time = start_time;
		this.skillname = skillname;
		this.mentor_name = mentor_name;
		this.self_rating = self_rating;
		this.years_of_experience = years_of_experience;
		this.facilities_offered = facilities_offered;
		this.amount = amount;
	}
	public long getSkill_id() {
		return skill_id;
	}
	public void setSkill_id(long skill_id) {
		this.skill_id = skill_id;
	}
	public long getMid() {
		return mid;
	}
	public void setMid(long mid) {
		this.mid = mid;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getSkillname() {
		return skillname;
	}
	public void setSkillname(String skillname) {
		this.skillname = skillname;
	}
	public String getMentor_name() {
		return mentor_name;
	}
	public void setMentor_name(String mentor_name) {
		this.mentor_name = mentor_name;
	}
	public int getSelf_rating() {
		return self_rating;
	}
	public void setSelf_rating(int self_rating) {
		this.self_rating = self_rating;
	}
	public float getYears_of_experience() {
		return years_of_experience;
	}
	public void setYears_of_experience(float years_of_experience) {
		this.years_of_experience = years_of_experience;
	}
	public String getFacilities_offered() {
		return facilities_offered;
	}
	public void setFacilities_offered(String facilities_offered) {
		this.facilities_offered = facilities_offered;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "SigninModel [skill_id=" + skill_id + ", mid=" + mid + ", end_time=" + end_time + ", start_time="
				+ start_time + ", skillname=" + skillname + ", mentor_name=" + mentor_name + ", self_rating="
				+ self_rating + ", years_of_experience=" + years_of_experience + ", facilities_offered="
				+ facilities_offered + ", amount=" + amount + "]";
	}

}
