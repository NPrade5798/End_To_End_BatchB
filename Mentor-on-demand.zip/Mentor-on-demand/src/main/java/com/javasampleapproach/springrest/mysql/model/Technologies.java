package com.javasampleapproach.springrest.mysql.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "technologies")
public class Technologies{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long skill_id;

	@Column(name="mid")
	private long mid;
	
	@Column(name="msid")
	private long msid;

	@Column(name="pid")
	private long pid;
	
	@Column(name="mcid")
	private long mcid;
	
	@Column(name = "skillname")
	private String skillname;

	@Column(name = "toc")
	private String toc;

	@Column(name = "duration")
	private String duration;
	
	@Column(name = "start_time")
	private String start_time;
	
	@Column(name = "prerequites")
	private String prerequites;
	
	
	public Technologies() {
		
	}


	public long getSkill_id() {
		return skill_id;
	}


	public void setSkill_id(long skill_id) {
		this.skill_id = skill_id;
	}


	public long getMid() {
		return mid;
	}


	public void setMid(long mid) {
		this.mid = mid;
	}


	public long getMsid() {
		return msid;
	}


	public void setMsid(long msid) {
		this.msid = msid;
	}


	public long getPid() {
		return pid;
	}


	public void setPid(long pid) {
		this.pid = pid;
	}


	public long getMcid() {
		return mcid;
	}


	public void setMcid(long mcid) {
		this.mcid = mcid;
	}


	public String getSkillname() {
		return skillname;
	}


	public void setSkillname(String skillname) {
		this.skillname = skillname;
	}


	public String getToc() {
		return toc;
	}


	public void setToc(String toc) {
		this.toc = toc;
	}


	public String getDuration() {
		return duration;
	}


	public void setDuration(String duration) {
		this.duration = duration;
	}


	public String getStart_time() {
		return start_time;
	}


	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}


	public String getPrerequites() {
		return prerequites;
	}


	public void setPrerequites(String prerequites) {
		this.prerequites = prerequites;
	}


	public Technologies(long skill_id, long mid, long msid, long pid, long mcid, String skillname, String toc,
			String duration, String start_time, String prerequites) {
		super();
		this.skill_id = skill_id;
		this.mid = mid;
		this.msid = msid;
		this.pid = pid;
		this.mcid = mcid;
		this.skillname = skillname;
		this.toc = toc;
		this.duration = duration;
		this.start_time = start_time;
		this.prerequites = prerequites;
	}


	@Override
	public String toString() {
		return "Technologies [skill_id=" + skill_id + ", mid=" + mid + ", msid=" + msid + ", pid=" + pid + ", mcid="
				+ mcid + ", skillname=" + skillname + ", toc=" + toc + ", duration=" + duration + ", start_time="
				+ start_time + ", prerequites=" + prerequites + "]";
	}


	
	
}