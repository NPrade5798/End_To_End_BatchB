package com.javasampleapproach.springrest.mysql.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.Technologies;
import com.javasampleapproach.springrest.mysql.model.Trainings;
import com.javasampleapproach.springrest.mysql.repo.TechnologiesRepository;

@CrossOrigin(origins="https://localhost:4200")

@RestController
@RequestMapping("/api")
public class TechnologiesController {
	@Autowired
	TechnologiesRepository repository;

	
	@GetMapping("/technologies/id/{id}")
	public Optional<Technologies> getSkill(@PathVariable("id") long id) {
		Optional<Technologies> technologies =repository.findById(id);
		return technologies;
	}
//	@GetMapping("/technologies/name/{name}")
//	public List<Technologies>  getSkillName(@PathVariable("name") String name) {
//
//		List<Technologies> technologies1= repository. getSkillName(name);
//        return technologies1;
//}
}
