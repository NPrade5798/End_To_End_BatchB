package com.javasampleapproach.springrest.mysql.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.Trainings;
import com.javasampleapproach.springrest.mysql.repo.TrainingsRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class TrainingsController {
	
	@Autowired
	TrainingsRepository repository;

	
	@GetMapping("/trainings")
	public List<Trainings> getAllTrainings() {
		System.out.println("Get all Trainings...");

		List<Trainings> trainings = new ArrayList<>();
		repository.findAll().forEach(trainings::add);

		return trainings;
	}

    @GetMapping("/trainings/getcompleted")
    public List<Trainings> getCompletedTraining()
    {
                  System.out.println("Get all Trainings of id...");
                  List<Trainings> trainings = repository.getCompletedTraining();
                  return trainings;
    }

    
    @GetMapping("/trainings/getunderprogress")
    public List<Trainings> getUnderProgressTrainings()
    {
                  System.out.println("Get all Trainings of id...");
                  List<Trainings> trainings = repository.getUnderProgressTrainings();
                  return trainings;
    }
    
    @GetMapping("/trainings/getapprovedtrainings")
    public List<Trainings> getApprovedTrainings()
    {
                  System.out.println("Get all Trainings of id...");
                  List<Trainings> trainings = repository. getApprovedTrainings();
                  return trainings;
    }
    
    @GetMapping("/trainings/getproposedtrainings")
    public List<Trainings> getProposedTrainings()
    {
                  System.out.println("Get all Trainings of id...");
                  List<Trainings> trainings = repository. getProposedTrainings();
                  return trainings;
    }
//	@PostMapping(value = "/trainings/create")
//	public ResponseEntity<Void> postTrainings(@RequestBody Trainings trainings) {
//		repository.save(trainings);
//		return new ResponseEntity<Void>(HttpStatus.CREATED);
//	}
}
