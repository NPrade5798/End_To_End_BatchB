import { Component, OnInit, HostListener } from '@angular/core';
import{Trainings} from '../training';
import { TrainingService } from '../trainings.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-trainersearch',
  templateUrl: './trainersearch.component.html',
  styleUrls: ['./trainersearch.component.css']
})
export class TrainersearchComponent implements OnInit {
  
  trainings : Observable<Trainings[]>;
  progresstrainings : Observable<Trainings[]>;
  statustrainings : Observable<Trainings[]>;
   constructor(private trainingService: TrainingService) { }
 
  ngOnInit() {
this.reloadData();
    
  }
  private reloadData()  {
    this.trainings = this.trainingService.getCompletedTraining();
    this.progresstrainings = this.trainingService.getUnderProgressTrainings();
    this.statustrainings = this.trainingService.getproposedtrainings();
  }
}
