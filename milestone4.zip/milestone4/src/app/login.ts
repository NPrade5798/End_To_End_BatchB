export class Login {
    emailid: String;
    password: String;
    role: String;
 
    
    constructor(emailid,password,role) {
       
       this.emailid = emailid;
       this.password = password;
      
       this.role = role;
   
    } 
}