export class User {
    emailid: String;
    password: String;
   firstname: String;
   lastname: String;
    user_id:Number;
     active:String;
   contact_number:String;
    reg_code:String;
    reg_datetime:String;
  username:String;
    
   
}