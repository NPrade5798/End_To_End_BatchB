import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../trainings.service';
import { Router } from '@angular/router';
import {Login } from '../login';
import { DataServiceService } from '../data-service.service';
@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  emailid: String;
  password: String;
  invalidLogin: boolean = false;
  login:Login[];
  
  
  constructor(private router: Router, private trainingService: TrainingService,private dataService: DataServiceService) { }

  ngOnInit() {
    this.trainingService.getCredentials().subscribe(response => this.login = response, error => alert(`${error.message}\nWaiting for response from server`));
 }
 checkLogin() {
  
  for (let i = 0; i < this.login.length; i++) {

    if (this.login[i].emailid === this.emailid && this.login[i].password === this.password) {
        if(this.login[i].role==="admin")
        {
      this.router.navigate(['adminpage']);
        }
        if(this.login[i].role === "mentor")
        {
          this.router.navigate(['mentorpage']);
        }
        if(this.login[i].role === "user")
        {
          this.router.navigate(['userrpage']);
        }
        this.invalidLogin = false;
      // localStorage.setItem("usersId", this.login[i].email.toString());
      this.dataService.setEmail(this.emailid);
       
    } else {
      this.invalidLogin = true;
    }
  }

}

onSubmit() { 

  console.log(this.emailid);
  this.checkLogin();
  
}

}





      