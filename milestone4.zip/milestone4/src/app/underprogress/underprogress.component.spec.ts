import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderprogressComponent } from './underprogress.component';

describe('UnderprogressComponent', () => {
  let component: UnderprogressComponent;
  let fixture: ComponentFixture<UnderprogressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnderprogressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderprogressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
