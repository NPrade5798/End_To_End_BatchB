import { Component, OnInit } from '@angular/core';
import{Trainings} from '../training';
import { TrainingService } from '../trainings.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-underprogress',
  templateUrl: './underprogress.component.html',
  styleUrls: ['./underprogress.component.css']
})
export class UnderprogressComponent implements OnInit {
  progresstrainings : Observable<Trainings[]>;
  constructor(private trainingService: TrainingService) { }

  ngOnInit() {
    this.reloadData();
  }
  private reloadData()  {
  this.progresstrainings = this.trainingService.getUnderProgressTrainings();
}
}
