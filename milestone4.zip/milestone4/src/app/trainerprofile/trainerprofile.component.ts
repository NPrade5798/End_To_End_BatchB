import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainerprofile',
  templateUrl: './trainerprofile.component.html',
  styleUrls: ['./trainerprofile.component.css']
})
export class TrainerprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
