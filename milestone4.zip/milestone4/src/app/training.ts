export class Trainings{
    id: bigint;
  
    user_id:bigint;
    skill_id:bigint;
    progress:Number;
   mentor_name:String;
   status:String;
   username:String;
   skill_name:String;
    
    

}

