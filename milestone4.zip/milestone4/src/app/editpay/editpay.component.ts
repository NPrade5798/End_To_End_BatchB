import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editpay',
  templateUrl: './editpay.component.html',
  styleUrls: ['./editpay.component.css']
})
export class EditpayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
