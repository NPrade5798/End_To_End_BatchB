export class Mentor {
    emailid: String;
    password: String;
   mentor_name: String;
    mid:Number;
     active:boolean;
    linkedin_url:String;
    reg_code:String;
    reg_datetime:String;
    years_of_experience:String;
    
   
}