import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../trainings.service';
import { Router } from '@angular/router';
import {User } from '../user';
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  emailid: String;
  password: String;
  invalidLogin: boolean = false;
  user:User[];
  constructor(private router: Router, private trainingService: TrainingService) { }

  ngOnInit() {
    this.trainingService.getCredentials1().subscribe(response => this.user = response, error => alert(`${error.message}\nWaiting for response from server`));
  }
  checkLogin() {
  
    for (let i = 0; i < this.user.length; i++) {
  
      if (this.user[i].emailid === this.emailid && this.user[i].password === this.password) {
      
        {
          this.router.navigate(['userrpage']);
          localStorage.setItem("user_id",this.user[i].user_id.toString());
          this.invalidLogin = false;
        }
     
       
      
      } else {
        this.invalidLogin = true;
      }
    }
}
onSubmit() { 

  console.log(this.emailid);
  this.checkLogin();
  
}
}
