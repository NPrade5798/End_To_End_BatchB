import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../trainings.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-userrpage',
  templateUrl: './userrpage.component.html',
  styleUrls: ['./userrpage.component.css']
})
export class UserrpageComponent implements OnInit {
  userid:number;
  user:User;
  constructor(private router: Router, private trainingService: TrainingService) { }

  ngOnInit() {
    let userid=localStorage.getItem("user_id") ;
    this.userid=parseInt(userid);
    console.log(userid);
  }

}
