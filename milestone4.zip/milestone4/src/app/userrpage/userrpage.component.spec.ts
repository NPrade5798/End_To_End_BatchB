import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserrpageComponent } from './userrpage.component';

describe('UserrpageComponent', () => {
  let component: UserrpageComponent;
  let fixture: ComponentFixture<UserrpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserrpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserrpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
