import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewskill',
  templateUrl: './viewskill.component.html',
  styleUrls: ['./viewskill.component.css']
})
export class ViewskillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
