export class Technologies{
    id: bigint;
  mentor_name:String
    mid:bigint;
    skill_id:bigint;
    self_rating:Number;
   years_of_experience:number;
   facilities_offered:String;
  start_time:String;
  end_time:String;
   skill_name:String;
    
    

}
