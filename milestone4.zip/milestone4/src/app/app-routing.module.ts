import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms";
import { Routes, RouterModule, ChildrenOutletContexts } from '@angular/router';
import { SignInComponent } from './sign-in/sign-in.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { ManagementorComponent } from './managementor/managementor.component';
import { EditpayComponent } from './editpay/editpay.component';
import { AddskillComponent } from './addskill/addskill.component';
import { ViewskillComponent } from './viewskill/viewskill.component';
import { TrainerprofileComponent } from './trainerprofile/trainerprofile.component';
import { MentorpageComponent } from './mentorpage/mentorpage.component';
import { UserrpageComponent } from './userrpage/userrpage.component';
import { UnderprogressComponent } from './underprogress/underprogress.component';
import { StatusComponent } from './status/status.component';
import { DisplayComponent } from './display/display.component';
import { TrainersearchComponent } from './trainersearch/trainersearch.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';
import { UserloginComponent } from './userlogin/userlogin.component';
const routes: Routes = [
  { path: '', redirectTo: 'sign-in', pathMatch: 'full' },
  { path: 'sign-in', component: SignInComponent },
  { path: 'usersignup', component: UsersignupComponent },
  { path: 'adminpage', component: AdminpageComponent },
  { path: 'mentorsignup', component: MentorsignupComponent },
  { path: 'loginpage', component: LoginpageComponent },
  { path: 'managementor', component: ManagementorComponent },
  { path: 'editpay', component: EditpayComponent },
  { path: 'addskill', component: AddskillComponent },
  { path: 'viewskill', component: ViewskillComponent },
  { path: 'trainerprofile', component: TrainerprofileComponent },
  { path: 'mentorpage', component: MentorpageComponent },
  {path:'display',component:DisplayComponent},
  {path:'mentorlogin',component:MentorloginComponent},
  {path:'userlogin',component:UserloginComponent},
  {path:'userrpage',component:UserrpageComponent,
  children: [
    {
      path: 'status', component: StatusComponent
    },
     {
      path: 'trainersearch', component: TrainersearchComponent
    },
    {
      path: 'underprogress', component: UnderprogressComponent
    }
  ]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),FormsModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
