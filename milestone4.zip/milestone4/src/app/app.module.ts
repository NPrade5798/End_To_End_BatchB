import { BrowserModule } from '@angular/platform-browser';
import {FormsModule,ReactiveFormsModule} from "@angular/forms";
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { ManagementorComponent } from './managementor/managementor.component';
import { EditpayComponent } from './editpay/editpay.component';
import { AddskillComponent } from './addskill/addskill.component';
import { ViewskillComponent } from './viewskill/viewskill.component';
import { TrainerprofileComponent } from './trainerprofile/trainerprofile.component';
import { TrainersearchComponent } from './trainersearch/trainersearch.component';
import { MentorpageComponent } from './mentorpage/mentorpage.component';
import { UserrpageComponent } from './userrpage/userrpage.component';
import { UnderprogressComponent } from './underprogress/underprogress.component';
import { StatusComponent } from './status/status.component';
import { DisplayComponent } from './display/display.component';
import { MentorloginComponent } from './mentorlogin/mentorlogin.component';
import { UserloginComponent } from './userlogin/userlogin.component';

@NgModule({
  declarations: [
    AppComponent,
    SignInComponent,
    UsersignupComponent,
    AdminpageComponent,
    MentorsignupComponent,
    LoginpageComponent,
    ManagementorComponent,
    EditpayComponent,
    AddskillComponent,
    ViewskillComponent,
    TrainerprofileComponent,
    TrainersearchComponent,
    MentorpageComponent,
    UserrpageComponent,
    UnderprogressComponent,
    StatusComponent,
    DisplayComponent,
    MentorloginComponent,
    UserloginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule ,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent],

})
export class AppModule { 
  
}
