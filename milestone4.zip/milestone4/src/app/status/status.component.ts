import { Component, OnInit, Input } from '@angular/core';
import{Trainings} from '../training';
import { TrainingService } from '../trainings.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {
  statustrainings : Observable<Trainings[]>;
  @Input() trainings: Trainings;
  constructor(private trainingService: TrainingService) { }

  ngOnInit() {
    this.reloadData();
  }
 ApproveProposal(isApprove: String) {
    this.trainingService.ApproveProposal({status: isApprove })
      .subscribe(
        data => {
          console.log(data);
          this.trainings = data as Trainings;
        },
        error => console.log(error));
  }
  
  deleteCustomers() {
    this.trainingService.deleteProposal()
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log('ERROR: ' + error));
  }
  private reloadData()  {
  this.statustrainings = this.trainingService.getproposedtrainings();
}
  

}
