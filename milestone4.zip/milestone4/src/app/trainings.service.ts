import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TrainingService {

  private baseUrl = 'http://localhost:9090/api/trainings/getcompleted';
  private baseUrl1 = 'http://localhost:9090/api/trainings/getunderprogress';
  private baseUrl2 = 'http://localhost:9090/api/trainings/getproposedtrainings';
  private baseUrl4 = 'http://localhost:9090/api/trainings/unapprove/{id}';
  private baseUrl3 = 'http://localhost:9090/api/trainings/approve/{id}';
  private baseUrl5 = 'http://localhost:9090/api/signin/search';
  private baseUrl6='http://localhost:9090/api/mentorlogin';
  private baseUrl7='http://localhost:9090/api/userlogin';
  constructor(private http: HttpClient) { }
  

  getCompletedTraining(): Observable<any> {

    return this.http.get(`${this.baseUrl}`);
  }
  getUnderProgressTrainings(): Observable<any> {
 
    return this.http.get(`${this.baseUrl1}`);
  }
  getproposedtrainings(): Observable<any> {
 
    return this.http.get(`${this.baseUrl2}`);
  }
  ApproveProposal(value:any): Observable<object> {
    return this.http.put(`${this.baseUrl3}`,value);
}
deleteProposal(): Observable<any> {
  return this.http.delete(`${this.baseUrl4}`);
}
getSkillName(skill_name:String,start_time:String): Observable<any> {
 return this.http.get(`${this.baseUrl5}/${skill_name}/${start_time}`);
}
getCredentials(): Observable<any> {
  return this.http.get<any>(`${this.baseUrl6}`);
}
getCredentials1(): Observable<any> {
  return this.http.get<any>(`${this.baseUrl7}`);
}
}