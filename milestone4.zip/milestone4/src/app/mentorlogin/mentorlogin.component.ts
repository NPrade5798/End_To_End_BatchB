import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../trainings.service';
import { Router } from '@angular/router';
import {Mentor } from '../mentor';

@Component({
  selector: 'app-mentorlogin',
  templateUrl: './mentorlogin.component.html',
  styleUrls: ['./mentorlogin.component.css']
})
export class MentorloginComponent implements OnInit {
  emailid: String;
  password: String;
  invalidLogin: boolean = false;
  mentor:Mentor[];
  
  constructor(private router: Router, private trainingService: TrainingService) { }

  ngOnInit() {
    this.trainingService.getCredentials().subscribe(response => this.mentor = response, error => alert(`${error.message}\nWaiting for response from server`));
  }
  checkLogin() {
  
    for (let i = 0; i < this.mentor.length; i++) {
  
      if (this.mentor[i].emailid === this.emailid && this.mentor[i].password === this.password) {
      
        {
          this.router.navigate(['mentorpage']);
          localStorage.setItem("mid",this.mentor[i].mid.toString());
          this.invalidLogin = false;
        }
     
       
      
      } else {
        this.invalidLogin = true;
      }
    }
}
onSubmit() { 

  console.log(this.emailid);
  this.checkLogin();
  
}
}