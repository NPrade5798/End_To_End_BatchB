import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../trainings.service';
import{Technologies} from '../display';
@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  skill_name:String;
  start_time:String;
  display:Technologies[];
 
  constructor(private trainingService: TrainingService) { }

  ngOnInit() {

   this.skill_name=null;
   this.start_time=null;
  
  }

  private getSkillName1() {
    console.log("methiod");
    this.trainingService.getSkillName(this.skill_name,this.start_time)
      .subscribe(display => this.display = display)  
    }

  onSubmit(){
    this.getSkillName1();
    console.log("sub");
  }


}
