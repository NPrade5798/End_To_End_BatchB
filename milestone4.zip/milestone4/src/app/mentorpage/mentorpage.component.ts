import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../trainings.service';
import { Router } from '@angular/router';
import { Mentor } from '../mentor';
@Component({
  selector: 'app-mentorpage',
  templateUrl: './mentorpage.component.html',
  styleUrls: ['./mentorpage.component.css']
})
export class MentorpageComponent implements OnInit {
mentorid:number;
mentor:Mentor;
  constructor(private router: Router, private trainingService: TrainingService) { }

  ngOnInit() {
    let mentorid=localStorage.getItem("mid") ;
    this.mentorid=parseInt(mentorid);
    console.log(mentorid);
//     if(!mentorid)

//     {
//       alert("loggedout");
//       this.router.navigate(['mentorlogin']);
//       return;
//     }
//     this.trainingService.getCompletedTraining(this.mentorid).subscribe(
//     async res =>{
//       this.mentor=await res;
//     },error => console.log(error)
//  }
// )
 }
}