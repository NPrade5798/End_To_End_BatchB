package com.javasampleapproach.springrest.mysql.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.javasampleapproach.springrest.mysql.model.User;
import com.javasampleapproach.springrest.mysql.repo.UserRepository;

@CrossOrigin(origins="http://localhost:4200")

@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	UserRepository repository;
	

	@GetMapping("/userlogin")
		public Iterable<User> getuserlogin() {
		Iterable<User> user = repository.findAll();
		return user;
	}
}
