package com.javasampleapproach.springrest.mysql.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "login")
public class Login {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long loginid;
	
	@Column(name = "emailid")
	private String emailid;
	@Column(name = "password")
	private String password;

	@Column(name = "role")
	private String role;


public Login(){
	
}


public Login(long loginid, String emailid, String password, String role) {
	super();
	this.loginid = loginid;
	this.emailid = emailid;
	this.password = password;
	this.role = role;
}


public long getLoginid() {
	return loginid;
}


public void setLoginid(long loginid) {
	this.loginid = loginid;
}


public String getEmailid() {
	return emailid;
}


public void setEmailid(String emailid) {
	this.emailid = emailid;
}


public String getPassword() {
	return password;
}


public void setPassword(String password) {
	this.password = password;
}


public String getRole() {
	return role;
}


public void setRole(String role) {
	this.role = role;
}


@Override
public String toString() {
	return "Login [loginid=" + loginid + ", emailid=" + emailid + ", password=" + password + ", role=" + role + "]";
}







	
	
	}
