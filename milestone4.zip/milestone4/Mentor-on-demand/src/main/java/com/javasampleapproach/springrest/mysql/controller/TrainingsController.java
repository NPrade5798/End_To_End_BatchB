package com.javasampleapproach.springrest.mysql.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.javasampleapproach.springrest.mysql.model.Mentor;
import com.javasampleapproach.springrest.mysql.model.Technologies;
import com.javasampleapproach.springrest.mysql.model.Trainings;
import com.javasampleapproach.springrest.mysql.model.TrainingsModel;
import com.javasampleapproach.springrest.mysql.model.User;
import com.javasampleapproach.springrest.mysql.model.Login;
import com.javasampleapproach.springrest.mysql.repo.MentorRepository;
import com.javasampleapproach.springrest.mysql.repo.TechnologiesRepository;
import com.javasampleapproach.springrest.mysql.repo.TrainingsRepository;
import com.javasampleapproach.springrest.mysql.repo.UserRepository;
import com.javasampleapproach.springrest.mysql.repo.LoginRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

@RequestMapping("/api")
public class TrainingsController {
	 
	@Autowired
	TrainingsRepository repository;
	@Autowired
	MentorRepository mrepository;
	@Autowired
	TechnologiesRepository trepository;
	@Autowired
	UserRepository urepository;
//	
//	@GetMapping("/trainings")
//	public List<Trainings> getAllTrainings() {
//		System.out.println("Get all Trainings...");
//
//		List<Trainings> trainings = new ArrayList<>();
//		repository.findAll().forEach(trainings::add);
//
//		return trainings;
//	}
    

//   @GetMapping("/trainings/getfinalizetrainings")
//   public List<Trainings> getFinalizeTrainings()
//   {
//                 System.out.println("Get all Trainings of id...");
//                  List<Trainings> trainings = repository. getFinalizeTrainings();
//                 return trainings;
//    }
//    
	

    @GetMapping("/trainings/getcompleted")
    
    public List<TrainingsModel> getCompletedTraining()
    {
    	
                  List<Trainings> tranings_list = repository.getCompletedTraining();
                 
                 List<TrainingsModel> traningsm_list = new ArrayList<TrainingsModel>();
          		for(Trainings tranings:tranings_list)
          		{
          			 
          			long mentor_id = tranings.getMentor_id();
          			long skill_id=tranings.getSkill_id();
          			long user_id=tranings.getUser_id();
          			
          			Optional<Mentor> mentor = mrepository.findById((long) mentor_id);
          			Optional<Technologies> technologies=trepository.findById((long) skill_id);
          			Optional<User> user=urepository.findById((long) user_id);
          		
          			TrainingsModel tmodel = new TrainingsModel(tranings.getId(),tranings.getUser_id(),
          					mentor.get().getMentor_name(),tranings.getStatus(),tranings.getProgress(),
          				user.get().getUsername(),	technologies.get().getSkillname());
          			
          			
          			traningsm_list.add(tmodel);
          		}
          		
          		return traningsm_list;
         	}
    


    @GetMapping("/trainings/getunderprogress")
 public List<TrainingsModel> getUnderProgressTrainings()
  {
                
                List<Trainings> tranings_list1 = repository.getUnderProgressTrainings();

                List<TrainingsModel> traningsm_list1 = new ArrayList<TrainingsModel>();
         		for(Trainings tranings:tranings_list1)
         		{
         			 
         			long mentor_id = tranings.getMentor_id();
         			long skill_id=tranings.getSkill_id();
         			long user_id=tranings.getUser_id();
         			
         			Optional<Mentor> mentor = mrepository.findById((long) mentor_id);
         			Optional<Technologies> technologies=trepository.findById((long) skill_id);
         			Optional<User> user=urepository.findById((long) user_id);
         		
         			TrainingsModel tmodel = new TrainingsModel(tranings.getId(),tranings.getUser_id(),
         					mentor.get().getMentor_name(),tranings.getStatus(),tranings.getProgress(),
         				user.get().getUsername(),	technologies.get().getSkillname());
         			
         			
         			traningsm_list1.add(tmodel);
         		}
         		return traningsm_list1;
  }


    
  @GetMapping("/trainings/getproposedtrainings")
  public List<TrainingsModel> getProposedTrainings()
  {
                
                List<Trainings> tranings_list2 = repository. getProposedTrainings();
               
                List<TrainingsModel> traningsm_list2 = new ArrayList<TrainingsModel>();
         		for(Trainings tranings:tranings_list2)
         		{
         			 
         			long mentor_id = tranings.getMentor_id();
         			long skill_id=tranings.getSkill_id();
         			long user_id=tranings.getUser_id();
         			
         			Optional<Mentor> mentor = mrepository.findById((long) mentor_id);
         			Optional<Technologies> technologies=trepository.findById((long) skill_id);
         			Optional<User> user=urepository.findById((long) user_id);
         		
         			TrainingsModel tmodel = new TrainingsModel(tranings.getId(),tranings.getUser_id(),
         					mentor.get().getMentor_name(),tranings.getStatus(),tranings.getProgress(),
         				user.get().getUsername(),	technologies.get().getSkillname());
         			
         			
         			traningsm_list2.add(tmodel);
         		}
         		return traningsm_list2;
  }
  


@PutMapping("/trainings/approve/{id}")
public ResponseEntity<Trainings> ApproveProposal(@PathVariable("id") long id)
{
	

	Optional<Trainings> trainingsData = repository.findById(id);

	if (trainingsData.isPresent()) {
		Trainings _customer = trainingsData.get();
		_customer.setStatus("approved");
//		_customer.setAge(customer.getAge());
//		_customer.setActive(customer.isActive());
		return new ResponseEntity<>(repository.save(_customer), HttpStatus.OK);
	} 
	else 
	{
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}

@PutMapping("/trainings/unapprove/{id}")
public ResponseEntity<Trainings> deleteproposal(@PathVariable("id") long id)
{


	Optional<Trainings> trainingsData = repository.findById(id);
	if (trainingsData.isPresent())
	{
		Trainings _customer = trainingsData.get();
		_customer.setStatus("unapproved");
		return new ResponseEntity<>(repository.save(_customer), HttpStatus.OK);
	} 
	else 
	{
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}
}	