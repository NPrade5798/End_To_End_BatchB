package com.javasampleapproach.springrest.mysql.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "mentor")
public class  Mentor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long mid;

	@Column(name = "mentor_name")
	private String mentor_name;

	@Column(name = "linkedin_url")
	private String linkedin_url;
	
	@Column(name = "reg_datetime")
	private String reg_datetime;
	
	@Column(name = "reg_code")
	private String reg_code;
	
	@Column(name = "years_of_experience")
	private float years_of_experience;
	
	@Column(name = "active")
	private boolean active;
	public Mentor() {
	
	}
	
	public Mentor(long id, String mentor_name, String linkedin_url, String reg_datetime, String reg_code,
			float years_of_experience, boolean active) {
		super();
		this.mid = mid;
		this.mentor_name = mentor_name;
		this.linkedin_url = linkedin_url;
		this.reg_datetime = reg_datetime;
		this.reg_code = reg_code;
		this.years_of_experience = years_of_experience;
		this.active = active;
	}


	
	public long getMid() {
		return mid;
	}



	public void setMid(long mid) {
		this.mid = mid;
	}



	public String getMentor_name() {
		return mentor_name;
	}



	public void setMentor_name(String mentor_name) {
		this.mentor_name = mentor_name;
	}



	public String getLinkedin_url() {
		return linkedin_url;
	}



	public void setLinkedin_url(String linkedin_url) {
		this.linkedin_url = linkedin_url;
	}



	public String getReg_datetime() {
		return reg_datetime;
	}



	public void setReg_datetime(String reg_datetime) {
		this.reg_datetime = reg_datetime;
	}



	public String getReg_code() {
		return reg_code;
	}



	public void setReg_code(String reg_code) {
		this.reg_code = reg_code;
	}



	public float getYears_of_experience() {
		return years_of_experience;
	}



	public void setYears_of_experience(float years_of_experience) {
		this.years_of_experience = years_of_experience;
	}



	public boolean isActive() {
		return active;
	}



	public void setActive(boolean active) {
		this.active = active;
	}



	@Override
	public String toString() {
		return "Customer [mid=" + mid + ", mentor_name=" + mentor_name + "linkedin_url=" + linkedin_url + ", reg_datetime=" + reg_datetime +",reg_code=" + reg_code +",years_of_experience=" + years_of_experience +", active=" + active + "]";
	}
}

