package com.javasampleapproach.springrest.mysql.repo;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.javasampleapproach.springrest.mysql.model.Mentor;
import com.javasampleapproach.springrest.mysql.model.MentorCalendar;
import com.javasampleapproach.springrest.mysql.model.Technologies;

	public interface MentorRepository extends CrudRepository<Mentor, Long>{
	
		@Query(value="SELECT * FROM mentor ", nativeQuery=true)
		 List<Mentor> getMentors(@Param("mid") long mid);
		//public List<Mentor> getMentors();
	

@Query(value="SELECT * FROM mentor  where name LIKE %?%",nativeQuery=true)
	List<Mentor> getMentorName(@Param("name") String status);
//public List<Mentor> getMentorName();
}