package com.javasampleapproach.springrest.mysql.model;

public class TrainingsModel {


private long id;

private long user_id;

private String mentor_name;

private String status;

private int progress;

private String username;

private String skillname;

public TrainingsModel(){
	}

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public long getUser_id() {
	return user_id;
}

public void setUser_id(long user_id) {
	this.user_id = user_id;
}

public String getMentor_name() {
	return mentor_name;
}

public void setMentor_username(String mentor_username) {
	this.mentor_name = mentor_name;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public int getProgress() {
	return progress;
}

public void setProgress(int progress) {
	this.progress = progress;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getSkillname() {
	return skillname;
}

public void setSkillname(String skillname) {
	this.skillname = skillname;
}

public TrainingsModel(long id, long user_id, String mentor_name, String status, int progress, String username,
		String skillname) {
	super();
	this.id = id;
	this.user_id = user_id;
	this.mentor_name = mentor_name;
	this.status = status;
	this.progress = progress;
	this.username = username;
	this.skillname = skillname;
}

@Override
public String toString() {
	return "TrainingsModel [id=" + id + ", user_id=" + user_id + ", mentor_name=" + mentor_name + ", status="
			+ status + ", progress=" + progress + ", username=" + username + ", skillname=" + skillname + "]";
}

}