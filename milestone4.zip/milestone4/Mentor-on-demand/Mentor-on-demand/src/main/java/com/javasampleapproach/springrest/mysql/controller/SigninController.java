package com.javasampleapproach.springrest.mysql.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.Mentor;
import com.javasampleapproach.springrest.mysql.model.MentorCalendar;
import com.javasampleapproach.springrest.mysql.model.MentorSkills;
import com.javasampleapproach.springrest.mysql.model.Payments;
import com.javasampleapproach.springrest.mysql.model.SigninModel;
import com.javasampleapproach.springrest.mysql.model.Technologies;
import com.javasampleapproach.springrest.mysql.model.Trainings;
import com.javasampleapproach.springrest.mysql.model.TrainingsModel;
import com.javasampleapproach.springrest.mysql.model.User;
import com.javasampleapproach.springrest.mysql.repo.MentorCalendarRepository;
import com.javasampleapproach.springrest.mysql.repo.MentorRepository;
import com.javasampleapproach.springrest.mysql.repo.MentorSkillsRepository;
import com.javasampleapproach.springrest.mysql.repo.PaymentsRepository;

import com.javasampleapproach.springrest.mysql.repo.TechnologiesRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

@RequestMapping("/api")

public class SigninController {
	@Autowired
	TechnologiesRepository trepository;
	@Autowired
	MentorRepository mrepository;
	@Autowired
	MentorSkillsRepository msrepository;
	@Autowired
	MentorCalendarRepository mcrepository;

	@Autowired
	PaymentsRepository prepository;
	

    @GetMapping("/signin/search/{skillname}/{start_time}")
    
    public List<SigninModel> getSkillName(@PathVariable("skillname")String skillname,@PathVariable("start_time")String start_time)
    {
    	
                  List<Technologies> tranings_list =  trepository.getSkillName(skillname,start_time);
                 
                 List<SigninModel> traningsm_list = new ArrayList<SigninModel>();
          		for(Technologies tranings:tranings_list)
          		{
          			 
        			
          			long skill_id=tranings.getSkill_id();
          			long mid=tranings.getMid();
          			long msid=tranings.getMsid();
          			long mcid=tranings.getMcid();
          			long pid=tranings.getPid();
         			
         						Optional<Technologies> technologies=trepository.findById((long) skill_id);
         						Optional<Mentor> mentor=mrepository.findById((long) mid);
         						Optional<MentorSkills> mentorskills=msrepository.findById((long) msid);
         						Optional<MentorCalendar> mentorcalendar=mcrepository.findById((long) mcid);
         						Optional<Payments> payments=prepository.findById((long) pid);
         	
         						
         						SigninModel tmodel = new SigninModel(technologies.get().getSkill_id(),mentor.get().getMid(),mentorcalendar.get().getEnd_time(),
         								mentorcalendar.get().getStart_time(),technologies.get().getSkillname(),mentor.get().getMentor_name(),mentorskills.get().getSelf_rating(),
         								mentorskills.get().getYears_of_experience(),mentorskills.get().getFacilities_offered(),payments.get().getAmount());
          			
          		
          	traningsm_list.add(tmodel);
          		}
          		
          		return traningsm_list;
         	}
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
