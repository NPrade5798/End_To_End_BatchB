package com.javasampleapproach.springrest.mysql.repo;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.javasampleapproach.springrest.mysql.model.Trainings;
public interface TrainingsRepository extends CrudRepository <Trainings, Long>{

    @Query(value="SELECT * FROM trainings  WHERE trainings.progress=100", nativeQuery=true)
    List<Trainings> getCompletedTraining();
    

    @Query(value="SELECT * FROM trainings  WHERE trainings.progress<100", nativeQuery=true)
    List<Trainings> getUnderProgressTrainings();
    
//    @Query(value="SELECT * FROM trainings  WHERE trainings.status='Approved'", nativeQuery=true)
//    List<Trainings> getApprovedTrainings();
//    
    @Query(value="SELECT * FROM trainings  WHERE trainings.status='propose'", nativeQuery=true)
    List<Trainings> getProposedTrainings();
    
    @Query(value="SELECT * FROM trainings  WHERE trainings.status='propose'", nativeQuery=true)
    List<Trainings> ApproveProposal();
    
//    @Query(value="SELECT * FROM trainings  WHERE trainings.status='Finalize'", nativeQuery=true)
//    List<Trainings> getFinalizeTrainings();
}
