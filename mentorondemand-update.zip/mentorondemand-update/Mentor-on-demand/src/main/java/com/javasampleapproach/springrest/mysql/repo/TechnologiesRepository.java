package com.javasampleapproach.springrest.mysql.repo;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.javasampleapproach.springrest.mysql.model.Technologies;



public interface TechnologiesRepository extends CrudRepository <Technologies, Long> {
	@Query(value="SELECT * FROM technologies ", nativeQuery=true)
	 List<Technologies> getSkill(@Param("id") long anitha);
}
