export class Customer {
    id: number;
    name: string;
    age: number;
    mobilenumber:string;
    active: boolean;
}
